
package com.mycompany.grafico;

import javax.swing.JFrame;

public class Extendida {
    public void extendida(){
  /*      Ventana ventana1 = new Ventana();
    }
}
class Ventana extends JFrame{
    public Ventana(){
        super("Mi ventana");
        setSize(300,200);
        setVisible(true);*/
    }
}