
package com.mycompany.grafico;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Componentes {
    public void venta_c(){
        JFrame miventana = new JFrame();
        miventana.setTitle("Ventana con componentes");
        miventana.setSize(500, 400);
        
        //Primero se crean los componentes y despues se agregan
        
        miventana.setLayout(new FlowLayout());
        JLabel etiqueta = new JLabel("Nombre");
        JTextField texto = new JTextField(20);
        JButton boton = new JButton("Saludar");
        
        miventana.add(etiqueta);
        miventana.add(texto);
        miventana.add(boton);
        
        miventana.setVisible(true);
    }
}
