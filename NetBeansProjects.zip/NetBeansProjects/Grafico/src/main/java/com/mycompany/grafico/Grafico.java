
package com.mycompany.grafico;

public class Grafico {

    public static void main(String[] args) {
        Dialogo dialogo = new Dialogo();
        dialogo.dialogos();
        
        
        Componentes venta_c = new Componentes();
        venta_c.venta_c();
        
        
        Ventana2 ventana = new Ventana2();
        ventana.setVisible(true);
        ventana.setTitle("Ventana 1");
        ventana.setLocationRelativeTo(null);
        
        
        Calculadora calcu = new Calculadora();
        calcu.setVisible(true);
        calcu.setLocationRelativeTo(null);
    }
}
