
package com.mycompany.grafico;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Dialogo {
    public void dialogos(){
        JFrame dialogo1 = new JFrame();
        //showMessageDialog
        JOptionPane.showMessageDialog(dialogo1,"Bienvenide a la parte grafica");
        
        //showInputDialog
        JFrame dialogo2 = new JFrame();
        String nombre = JOptionPane.showInputDialog(dialogo2,"Ingresa tu nombre");
        JOptionPane.showMessageDialog(dialogo2,"Bienvenido " + nombre);
        
        //showConfirmDialog
        JFrame dialogo3 = new JFrame();
        int resultado = JOptionPane.showConfirmDialog(dialogo3,"Preciona un boton");
        if(resultado == 0){
            JOptionPane.showMessageDialog(dialogo3, "Precionaste Si");
        }else if(resultado == 1){
            JOptionPane.showMessageDialog(dialogo3, "Precionaste No");
        }else{
            JOptionPane.showMessageDialog(dialogo3, "Precionaste Cancelar");
        }
    }
}
