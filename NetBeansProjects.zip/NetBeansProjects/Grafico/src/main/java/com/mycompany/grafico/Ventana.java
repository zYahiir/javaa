
package com.mycompany.grafico;

import javax.swing.JFrame;

public class Ventana {
    public void ventana(){
        JFrame ventana1 = new JFrame();
        ventana1.setSize(1000,1000);
        ventana1.setVisible(true);
        ventana1.setTitle("VENTANA 1");
        ventana1.setResizable(false);
    }
}
