/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto;

/**
 *
 * @author PILARES
 */
public class Proyecto {

    public static void main(String[] args) {
        int[] numeros = {12,10,4,24,5,9};
        for(int i=0; i<numeros.length;i++){
            System.out.println("Pisicion: " + i + "\nValor:" + numeros[i]);
        }
    }
}
