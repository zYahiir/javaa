
package com.mycompany.sistemaempleados.logica;

public class EmpleadoForaneo extends Empleado{
    private String provincia;

    public EmpleadoForaneo() {
    }

    public EmpleadoForaneo(String provincia) {
        this.provincia = provincia;
    }

    public EmpleadoForaneo(String provincia, int empleado, String nombre, String correo, String telefono, String fecha_nac, char genero, String domicilio) {
        super(empleado, nombre, correo, telefono, fecha_nac, genero, domicilio);
        this.provincia = provincia;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }
    
    
    public void mostrarDatos(){
        System.out.println("# " + this.empleado + "\nNombre: " + this.nombre + "\nCorreo: " + this.correo + "\nTelefono: " + this.telefono + "\nFecha de nacimiento: " + this.fecha_nac + "\nGenero: " + this.genero + "\nDomicilio: " + this.domicilio+ "\nEstado: " + this.provincia);
    }
  
}
