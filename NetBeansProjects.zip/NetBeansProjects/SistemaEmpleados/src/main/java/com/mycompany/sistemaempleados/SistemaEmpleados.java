
package com.mycompany.sistemaempleados;

import com.mycompany.sistemaempleados.logica.Empleado;
import com.mycompany.sistemaempleados.logica.EmpleadoForaneo;

public class SistemaEmpleados {

    public static void main(String[] args) {
        /*
        //Instaciamos el primer empleado
        
        Empleado empleado1 = new Empleado();
        
        Empleado empleado2 = new Empleado(2,"Juan","yahirguzman@gmail.com","5528895479","28/12/03",'M',"San Martin de Porres");
        
        //Ingresamos datos del objeto 1 que se hizo con el constructor vacio
        
        empleado1.setEmpleado(1);
        empleado1.setNombre("Yahir");
        empleado1.setCorreo("holaa12@gmail.com");
        empleado1.setTelefono("5456656876");
        empleado1.setFecha_nac("03/09/02");
        empleado1.setGenero('M');
        empleado1.setDomicilio("Las Americas");
        
        empleado1.mostrarDatos();
        System.out.println("\n");
        empleado2.mostrarDatos();
        
        //Instaciamos un empleado de privincia
        
        EmpleadoForaneo foraneo1 = new EmpleadoForaneo();
        foraneo1.setEmpleado(3);
        foraneo1.setNombre("Rodrigo");      
        foraneo1.setCorreo("rodri354@gmail.com");
        foraneo1.setTelefono("5698768798");
        foraneo1.setFecha_nac("23/09/12");
        foraneo1.setGenero('M');
        foraneo1.setDomicilio("Palomas");
        foraneo1.setProvincia("Chiapas");
        
        foraneo1.mostrarDatos();
        */
        
        //Instancia un nuevo empleado para el metodo
        
        Empleado empleado3 = new Empleado();
        empleado3.capturarDatos();
        
        
    }
}
