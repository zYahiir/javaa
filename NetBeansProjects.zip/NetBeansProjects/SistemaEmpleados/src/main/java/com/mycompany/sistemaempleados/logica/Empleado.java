
package com.mycompany.sistemaempleados.logica;

import java.util.Scanner;

public class Empleado {
    //Atributos
    protected int empleado;
    protected String nombre;
    protected String correo;
    protected String telefono;
    protected String fecha_nac;
    protected char genero;
    protected String domicilio;
    
    //Creamos el metodo constructor siempre se hacen los dos
    
    //Constructor sin datos

    public Empleado() {
    }
    
    //Creamos constructor con datos

    public Empleado(int empleado, String nombre, String correo, String telefono, String fecha_nac, char genero, String domicilio) {
        this.empleado = empleado;
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.fecha_nac = fecha_nac;
        this.genero = genero;
        this.domicilio = domicilio;
    }
    
    //Creamos los getter y setters para poder consultar y modificar los atributos

    public int getEmpleado() {
        return empleado;
    }

    public void setEmpleado(int empleado) {
        this.empleado = empleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getFecha_nac() {
        return fecha_nac;
    }

    public void setFecha_nac(String fecha_nac) {
        this.fecha_nac = fecha_nac;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }
    
    public void mostrarDatos(){
        System.out.println("# " + this.empleado + "\nNombre: " + this.nombre + "\nCorreo: " + this.correo + "\nTelefono: " + this.telefono + "\nFecha de nacimiento: " + this.fecha_nac + "\nGenero: " + this.genero + "\nDomicilio: " + this.domicilio);
    }
    
    public void capturarDatos(){
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingresa el nombre del empleado:");
        this.nombre = entrada.nextLine();
        System.out.println("La longitud del nombre es: "+ this.nombre.length());
        
        if(this.nombre.length()>5){
            System.out.println("El nombre es largo");
        }else{
            System.out.println("El nombre es corto");
        }
    }
    
}
