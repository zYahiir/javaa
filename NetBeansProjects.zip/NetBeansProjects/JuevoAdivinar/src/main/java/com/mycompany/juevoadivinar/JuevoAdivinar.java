
package com.mycompany.juevoadivinar;

import com.mycompany.juevoadivinar.logica.Jugador;

/**
 *
 * @author PILARES
 */
public class JuevoAdivinar {

    public static void main(String[] args) {
        Jugador jugador1 = new Jugador();
        jugador1.setNickname("Yahiir");
        jugador1.jugar();
        jugador1.mostrar_datos();
        
        Jugador jugador2 = new Jugador();
        jugador2.setNickname("Andrea");
        jugador2.jugar();
        jugador2.mostrar_datos();
        
        Jugador jugador3 = new Jugador();
        jugador3.setNickname("Andrea");
        jugador3.jugar();
        jugador3.mostrar_datos();
    }
}
