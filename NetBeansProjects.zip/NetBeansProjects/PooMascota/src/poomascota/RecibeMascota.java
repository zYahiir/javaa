/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poomascota;

/**
 *
 * @author PILARES
 */
public class RecibeMascota {
    String nombrePerro;
    int edad;
    String raza;
    String tamano;
    String nombreDueno;

    public RecibeMascota(String nombrePerro, int edad, String raza, String tamano, String nombreDueno){
        this.nombrePerro = nombrePerro;
        this.edad = edad;
        this.raza = raza;
        this.tamano = tamano;
        this.nombreDueno = nombreDueno;
    }
    
    public String getNombrePerro(){
        return nombrePerro;
    }
    public int getEdad(){
        return edad;
    }
    public String getRaza(){
        return raza;
    }
    public String getTamano(){
        return tamano;
    }
    public String getNombreDueno(){
        return nombreDueno;
    }

    public void setNombrePerro(String nombrePerro){
        this.nombrePerro = nombrePerro;
    }
    public void setEdad(int edad){
        this.edad = edad;
    }
    public void setRaza(String raza){
        this.raza = raza;
    }
    public void setTamano(String tamano){
        this.tamano = tamano;
    }
    public void setNombreDueno(String nombreDueno){
        this.nombreDueno = nombreDueno;
    }
}
