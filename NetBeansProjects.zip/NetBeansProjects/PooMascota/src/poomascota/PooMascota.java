/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poomascota;
import java.util.ArrayList;
/**
 *
 * @author PILARES
 */
public class PooMascota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<RecibeMascota> clientesActuales = new ArrayList();

        RecibeMascota cliente1 = new RecibeMascota("Pulgas", 5, "Chihuahua", "25 cm", "Luis");
        clientesActuales.add(cliente1);

        System.out.println("El número de clientes activos son: " + clientesActuales.size());
    }
    
}
