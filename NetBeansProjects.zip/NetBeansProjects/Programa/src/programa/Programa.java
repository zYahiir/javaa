
package programa;

public class Programa {

    public static void main(String[] args) {
            int edad = 20;
            double salarioDeseado = 70000.00;
            char genero = 'M';
            boolean buscandoTrabajo = true;
            System.out.println(edad);
            System.out.println(salarioDeseado);
            System.out.println(genero);
            System.out.println(buscandoTrabajo);
        
    }
    
}
