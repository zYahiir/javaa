
package com.mycompany.sistemamascota;

import com.mycompany.sistemamascota.logica.RecibeMascota;

import java.util.ArrayList;

public class SistemaMascota {

        
    public static void main(String[] args) {
        //Creamos objeto del constructor vacio
        RecibeMascota mascota1 = new RecibeMascota();
        
        mascota1.setNombre_mascota("Bobi");
        mascota1.setEdad_mascota(4);
        mascota1.setRaza("Chihuahua");
        mascota1.setTamaño(17.3);
        mascota1.setNombre_dueño("Juan Perez");
        
        RecibeMascota mascota2 = new RecibeMascota("Tobi",3,"Chihuahua",12.2,"Pedro");
        
        mascota1.mostrarDatos();
        mascota2.mostrarDatos();
        
        //Declaramos ArrayList
        ArrayList<RecibeMascota>mascotas = new ArrayList<>();
        mascotas.add(0,mascota1);
        mascotas.add(1,mascota2);
        System.out.println("Mascotas registrdas: "+mascotas.size());
    }
}
