
package com.mycompany.sistemamascota.logica;

public class RecibeMascota {
    //Atributos
    
    private String nombre_mascota;
    private int edad_mascota;
    private String raza;
    private double tamaño;
    private String nombre_dueño;
    
    //Metodos
    //Metodos constructores

    public RecibeMascota() {
    }

    public RecibeMascota(String nombre_mascota, int edad_mascota, String raza, double tamaño, String nombre_dueño) {
        this.nombre_mascota = nombre_mascota;
        this.edad_mascota = edad_mascota;
        this.raza = raza;
        this.tamaño = tamaño;
        this.nombre_dueño = nombre_dueño;
    }
    
    //Gatters and setters

    public String getNombre_mascota() {
        return nombre_mascota;
    }

    public void setNombre_mascota(String nombre_mascota) {
        this.nombre_mascota = nombre_mascota;
    }

    public int getEdad_mascota() {
        return edad_mascota;
    }

    public void setEdad_mascota(int edad_mascota) {
        this.edad_mascota = edad_mascota;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public double getTamaño() {
        return tamaño;
    }

    public void setTamaño(double tamaño) {
        this.tamaño = tamaño;
    }

    public String getNombre_dueño() {
        return nombre_dueño;
    }

    public void setNombre_dueño(String nombre_dueño) {
        this.nombre_dueño = nombre_dueño;
    }
    
    
    //Metodo que permite ver todos los datos
    
    public void mostrarDatos(){
        System.out.println("Nombre mascota: " + this.nombre_mascota + "\nEdad: " + this.edad_mascota + "\nRaza: " + this.raza + "\nTamano: " + this.tamaño + "\nDueno: " + this.tamaño);
        
    }
}
