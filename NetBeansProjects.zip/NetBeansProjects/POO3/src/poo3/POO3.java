/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poo3;
import java.util.ArrayList;
/**
 *
 * @author PILARES
 */
public class POO3 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Cuenta> cuentasActuales = new ArrayList();
        
        Cuenta cuenta1 = new Cuenta("Beatriz", 25, 1000, 0, 0);
        cuentasActuales.add(cuenta1);
        Cuenta cuenta2 = new Cuenta("Alejandro", 56, 5000, 0, 0);
        cuentasActuales.add(cuenta2);
        Cuenta cuenta3 = new Cuenta("Pedro", 23, 2000, 0, 0);
        cuentasActuales.add(cuenta3);
        Cuenta cuenta4 = new Cuenta("Angel",43, 500, 0, 0);
        cuentasActuales.add(cuenta4);
        CuentaJoven cuentaJoven1 = new CuentaJoven(false,"Luis", 19, 300, 0, 0);
        cuentasActuales.add(cuentaJoven1);
        
        System.out.println("El numero de cuentas activas es: " + cuentasActuales.size());
        
        
    }
    
}
