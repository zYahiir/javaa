/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo3;
import java.util.Scanner;
/**
 *
 * @author PILARES
 */
public class Cuenta {
    String titular;
    int edad;
    double cantidadTotal;
    double cantidadIngreso;
    double cantidadRetiro;
    Scanner sc = new Scanner(System.in);

    public Cuenta(String titular, int edad, double cantidadTotal, double cantidadIngreso, double cantidadRetiro) {
        this.titular = titular;
        this.edad = edad;
        this.cantidadTotal = cantidadTotal;
        this.cantidadIngreso = cantidadIngreso;
        this.cantidadRetiro = cantidadRetiro;
    }

    public String getTitular() {
        return titular;
    }

    public int getEdad() {
        return edad;
    }

    public double getCantidadTotal() {
        return cantidadTotal;
    }

    public double getCantidadIngreso() {
        return cantidadIngreso;
    }

    public double getCantidadRetiro() {
        return cantidadRetiro;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setCantidadTotal(double cantidadTotal) {
        this.cantidadTotal = cantidadTotal;
    }

    public void setCantidadIngreso(double cantidadIngreso) {
        this.cantidadIngreso = cantidadIngreso;
    }

    public void setCantidadRetiro(double cantidadRetiro) {
        this.cantidadRetiro = cantidadRetiro;
    }
    
    
    public void mostrar(){
        System.out.println("Titular: " + titular);
        System.out.println("Cantidad: " + cantidadTotal);
    }
    
    public void ingresar(){
        System.out.println("Cual será la cantidad a ingresar");
        cantidadIngreso = sc.nextDouble();
        cantidadTotal = cantidadTotal + cantidadIngreso;
        System.out.println("Tu saldo es: " + cantidadTotal);
    }
    
    public void retirar(){
        System.out.println("Cual será la cantidad a retirar");
        cantidadRetiro = sc.nextDouble();
        cantidadTotal = cantidadTotal - cantidadRetiro;
        System.out.println("Tu saldo restante es: " + cantidadTotal);
    }
    
    
}
