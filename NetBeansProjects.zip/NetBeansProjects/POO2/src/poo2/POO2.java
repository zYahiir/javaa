/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poo2;
import java.util.ArrayList;
/**
 *
 * @author PILARES
 */
public class POO2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ArrayList<Usuario> usuariosActuales = new ArrayList();
       
       Usuario usuario1 = new Usuario("Alejandro", "Folio1", 23);
       usuariosActuales.add(usuario1);
       
       Usuario usuario2 = new Usuario("Maria", "Folio2", 25);
       usuariosActuales.add(usuario2);
       
       Usuario usuario3 = new Usuario("Daniela", "Folio3", 22);
       usuariosActuales.add(usuario3);
       
       Usuario usuario4 = new Usuario("Jorge", "Folio4", 27);
       usuariosActuales.add(usuario4);
       
        System.out.println("El total de usuarios es " + usuariosActuales.size());
       
    }
}
