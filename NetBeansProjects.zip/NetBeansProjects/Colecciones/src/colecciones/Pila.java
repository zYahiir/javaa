
package colecciones;

import java.util.Stack;

public class Pila {
    public void pila(){
    Stack<String>camisas = new Stack<String>();
    camisas.push("Camisa blanca");
    camisas.push("Camisa roja");
    camisas.push("Camisa verde");
    camisas.push("Camisa negra");
    
        System.out.println(camisas);
    
    camisas.pop();
        System.out.println(camisas);
        
        System.out.println(camisas.peek()); 
        
        System.out.println("Posicion de la camisa verde:" + camisas.search("Camisa verde"));
        System.out.println("La pila esta vacia?: " + camisas.empty());
        
        while(camisas.empty() == false){
            System.out.println(camisas.peek());
            camisas.pop();
            
        }

    }
    



}
