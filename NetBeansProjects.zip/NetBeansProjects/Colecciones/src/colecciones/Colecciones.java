
package colecciones;

public class Colecciones {

    public static void main(String[] args) {
        
        /*
        //Creamos el objeto de pila y usamos su metodo
        Pila pila1 = new Pila();
        pila1.pila();
        
        
        //Cola
        Colas cola1 = new Colas();
        cola1.cola();

        Linked_List lista1 = new Linked_List();
        lista1.linkedlist();
        
        
        //Arreglo
        Arreglo arreglo1 = new Arreglo();
        arreglo1.arreglo();
        
        
        Matrices matriz1 = new Matrices();
        matriz1.matriz();

        */
        Ordenamiento orden1 = new Ordenamiento();
        orden1.ordenamientos();
        
    }
    
}
