
package colecciones;

import java.util.LinkedList;
import java.util.Queue;

public class Colas {
    public void cola(){
        Queue <String> nombres = new LinkedList();
        nombres.add("Yahir");
        nombres.offer("Andrea");
        nombres.offer("Juan");
        nombres.offer("Maria");
        nombres.offer("Pedro");
        
        System.out.println("Nombre a eliminar: " + nombres.element());
        nombres.poll();
        System.out.println(nombres);
        System.out.println("Nombre a eliminar: " + nombres.element());
        nombres.poll();
        System.out.println(nombres);
        System.out.println("Nombre a eliminar: " + nombres.element());
        nombres.poll();
        System.out.println(nombres);
    }
}
