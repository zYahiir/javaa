
package colecciones;

public class Matrices {
    public void matriz(){
        // int[][] calificaciones = new int [3][4];
        int[][] calificaciones = {{5,6},{3,5,8},{4}};
        System.out.println(calificaciones[1][2]);
        calificaciones [1] [2] = 10;
        
        for(int i=0; i<calificaciones.length; i++){
            for(int j=0; j<calificaciones[i]; j++){
                System.out.println(calificaciones[i][j] + "\n");
            }
            
        }
    }
}
