
package colecciones;

import java.util.LinkedList;

public class Linked_List {
    public void linkedlist(){
        LinkedList <String> lista = new LinkedList<>();
        lista.add(0,"Python");
        lista.add(1,"C++");
        lista.add(2,"C#");
        lista.add(3,"Java");
        lista.add(4,"Rubi");
        System.out.println(lista);
        
        System.out.println(lista);
        System.out.println(lista.get(0));
        
        lista.remove(0);
        System.out.println(lista);
        lista.set(4,"JavaScript");
        System.out.println(lista);
        
    }
}
