
package colecciones;

public class Arreglo {
    public void arreglo(){
        double[] precios = {3.4,5.6,56.6};
        System.out.println(precios);
        System.out.println(precios[0]);
        
        
        for(int i=0; i<precios.length; i++){
            System.out.println(precios[i]);
        }
        
        
    }
}
