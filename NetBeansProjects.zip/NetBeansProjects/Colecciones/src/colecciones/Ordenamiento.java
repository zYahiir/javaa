
package colecciones;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Ordenamiento {
    public void ordenamientos(){
        
        //Creamos el arreglo
        Scanner entrada = new Scanner(System.in);
        int[] arreglo;
        int n_elementos, posicion,auxiliar;
        n_elementos = Integer.parseInt(JOptionPane.showInputDialog("Numero del tamaño del arreglo"));
        arreglo = new int[n_elementos];
        
        for(int i=0; i<arreglo.length; i++){
            System.out.println("Ingresa un numero para la posicion " + (i+1)+ ":");
            arreglo[i]=entrada.nextInt();
        }
        
        //Metodo de burbuja
        for(int i=0; i<(n_elementos-1); i++){
            for(int j=0; j<(n_elementos-1); j++){
                if(arreglo[j]>arreglo[j+1]){
                    auxiliar=arreglo[j];
                    arreglo[j]= arreglo[j+1];
                    arreglo[j+1]= auxiliar;
                    
                }
            }
        }
        
        //Visualizar ya acomodado
        for(int i=0; i<arreglo.length;i++){
            System.out.println(arreglo[i]);
        }
        
        
        //Metodo por insercion
        for(int i=0; i<n_elementos; i++){
            posicion = i;
            auxiliar=arreglo[i];
            while((posicion>0)&&(arreglo[posicion-1]>auxiliar)){
                arreglo[posicion]=arreglo[posicion-1];
                posicion--;
            }
            arreglo[posicion]=auxiliar;
        }
        //Visualizar
            for(int i=0; i<arreglo.length;i++){
            System.out.println(arreglo[i]);
        }
            
        //Metodo Rapido
            
        
    }
    
              
}
