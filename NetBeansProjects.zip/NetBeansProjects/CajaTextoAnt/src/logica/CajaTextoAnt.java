/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package logica;

import gui.Ventana;
import gui.VentanaPrincipal;

/**
 *
 * @author PILARES
 */
public class CajaTextoAnt {
    public static void main(String []args){
        VentanaPrincipal pantalla1 = new VentanaPrincipal();
        pantalla1.setVisible(true);
        pantalla1.setResizable(false);
        pantalla1.setLocation(null);
        pantalla1.setTitle("Ventana");
    }
    
}
