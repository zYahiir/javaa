/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ordenamiento;
import java.util.Scanner;
import javax.swing.JOptionPane;
/**
 *
 * @author PILARES
 */
public class Ordenamiento {

    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arreglo[],elementos,auxiliar,posicion;
        
        elementos = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de elementos"));
        arreglo = new int[elementos];
        for(int i = 0; i < elementos; i++){
            System.out.println("Ingresa el elemento " + i);
            arreglo[i] = sc.nextInt();
        }
        
        //Ordenamiento de burbuja
        for(int i = 0; i < (elementos-1); i++){
            for(int j = 0; j < (elementos-1); j++){
                if(arreglo[j] < arreglo[j+1]){
                    auxiliar = arreglo[j];
                    arreglo[j] = arreglo[j+1];
                    arreglo[j+1] = auxiliar;
                }
            }
        }
        //Mandamos a imprimir el arreglo de forma ascendente y descendente.
        System.out.println("Arreglo descendente");
        for(int i = 0; i < elementos; i++){
            System.out.println(arreglo[i]);
        }
        
        System.out.println("Arreglo ascendente");
        for(int i = elementos-1; i >= 0; i--){
            System.out.println(arreglo[i]);
        }
        
    }
    
}
