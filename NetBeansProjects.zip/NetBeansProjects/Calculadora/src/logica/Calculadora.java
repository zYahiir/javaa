/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package logica;

import gui.Ventana;

/**
 *
 * @author PILARES
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Ventana pantalla1 = new Ventana();
       pantalla1.setVisible(true);
    }
    
}
