
package com.mycompany.sistemadeempleados.Logica;

import com.mycompany.sistemadeempleados.Persistencia.ControladoraPersistencia;

public class ControladoraLogica {
    ControladoraPersistencia controladorpersis = new ControladoraPersistencia();

    public void guardar(String text, String text0, String text1, String text2, String sexo) {
        Empleado empleado = new Empleado();
        empleado.setNombre_empleado(text);
        empleado.setTelefono(text0);
        empleado.setDireccion(text1);
        empleado.setCorreo(text2);
        empleado.setGenero(sexo);
        controladorpersis.guardar(empleado);
    }
    
}
