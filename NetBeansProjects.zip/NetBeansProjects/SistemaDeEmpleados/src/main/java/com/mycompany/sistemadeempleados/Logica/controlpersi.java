
package com.mycompany.sistemadeempleados.Logica;

class controlpersi {

    static void guardar(Empleado empleado) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
