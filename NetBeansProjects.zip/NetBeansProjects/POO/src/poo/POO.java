/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poo;

/**
 *
 * @author PILARES
 */
public class POO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Usuario usuario1 = new Usuario("Alejandro", "Xochimilcas 33", "ejemplo1@gmail.com", 23, "5620347768");
        System.out.println("Nombre: " + usuario1.getNombre());
        System.out.println("Direccion: " + usuario1.getDireccion());
        System.out.println("Correo: " + usuario1.getCorreo());
        System.out.println("Edad: " + usuario1.getEdad());
        System.out.println("Telefono: " + usuario1.getTelefono());
        usuario1.setNombre("Juan");
        System.out.println("Nombre: " + usuario1.getNombre());
        
        /*Generación de atributos para un modo constructor vacío*/
        Usuario usuario2 = new Usuario();
        usuario2.setNombre("Daniela");
        usuario2.setDireccion("Opatas 34");
        
        
        Menor menor1 = new Menor("Fatima", "Rodrigo", "Chalcas 45", "ejemplo3@gmail.com", 12, "5520409070" );
    }
    
    
    
    
}
